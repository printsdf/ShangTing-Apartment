const c="/static/ico/favicon-c932cd97.ico";export{c as d};
